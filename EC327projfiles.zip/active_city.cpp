#include <SFML/Graphics.hpp>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <curl/curl.h>
#include <algorithm>
#include "Button.h"
#include "Textbox.h"
#include "GenerateActivities.h"

using namespace std;
using namespace sf;

#define Width 800
#define Height 600

//Suggest the activities
void Suggest_Activity(RenderWindow& window, const string city, const string hour)
{
    bool ToF = false;
    int time = stoi(hour); //Update to if statment to prevent crashing

    //Load in the font
    Font f1;
    f1.loadFromFile("coolvetica rg.otf");

    //Create the title bar for the page
    Text title_bar;
    title_bar.setFont(f1);
    title_bar.setString("Suggested Activities:");
    title_bar.setCharacterSize(40);
    title_bar.setFillColor(sf::Color(20,100,200));

    //Create the activity
    vector<string> activities = getActivity(city, time, getWeather(city));

    Text activity_text_1;
    string activity_text_1_st = "1. ";
    activity_text_1_st += activities[0];
    activity_text_1.setFont(f1);
    activity_text_1.setString(activity_text_1_st);
    activity_text_1.setCharacterSize(24);
    activity_text_1.setFillColor(Color::Black);

    Text activity_text_2;
    Text activity_text_3;

    if(activities.size() >= 2)
    {
        string activity_text_2_st = "2. ";
        activity_text_2_st += activities[1];
        activity_text_2.setFont(f1);
        activity_text_2.setString(activity_text_2_st);
        activity_text_2.setCharacterSize(24);
        activity_text_2.setFillColor(Color::Black);
        if(activities.size() == 3)
        {
            string activity_text_3_st = "3. ";
            cout << activities[2] << endl;
            activity_text_3_st += activities[2];
            activity_text_3.setFont(f1);
            activity_text_3.setString(activity_text_3_st);
            activity_text_3.setCharacterSize(24);
            activity_text_3.setFillColor(Color::Black);
        }  
    }
    

    

    //Create the back button
    Button backButton("Back", {100, 50}, 24, Color::Black, Color::White);
    backButton.setFont(f1);
    backButton.setPosition({25, 525});

    while(window.isOpen())
    {
        Event event;

        while(window.pollEvent(event))
        {
            switch (event.type)
            {
            case Event::Closed:
                window.close();
                break;
            case Event::MouseMoved:
                if(backButton.isMouseOver(window))
                {
                    backButton.setTextColor(Color::Black);
                    backButton.setBackColor(Color::White);
                } else
                {
                    backButton.setTextColor(Color::White);
                    backButton.setBackColor(Color::Black);  
                }
                break;
            case Event::MouseButtonPressed:
                if(backButton.isMouseOver(window))
                {
                    ToF = true;
                }
                break;
            }
        }
        //clear the window
        window.clear(Color(200,200,200));

        //draw to the window
        window.draw(title_bar);
        window.draw(activity_text_1);
        if(activities.size() >= 2)
        {
           window.draw(activity_text_2); 
           activity_text_2.setPosition(0.f, 200.f);
           if(activities.size() == 3)
           {
                window.draw(activity_text_3);
                activity_text_3.setPosition(0.f, 300.f);
           }
        }
        
        
        backButton.drawTo(window);

        //Set the position of the objects
        title_bar.setPosition(0.f, 0);
        activity_text_1.setPosition(0.f, 100.f);
        
        

        //Display the window
        window.display();

        if(ToF)
        {
            break;
        }
    }
}

bool isIntegerString(const std::string& str) {
    // Iterate through each character in the string
    for (char c : str) {
        if (!std::isdigit(c)) {
            return false; // If any character is not a digit, return false
        }
    }
    return true; // All characters are digits
}

//Get the time as an input and pull the weather from the backend
void Time_Weather(RenderWindow& window, const string city)
{   
    bool ToF = false;
    string time_st;
    string char_to_find = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz`~!@#$%^&*()-_=+[{}];:'/?.>,<";
    //Load in the font
    Font f1;
    f1.loadFromFile("coolvetica rg.otf");

    //Create the titlebar for the page
    string title_string = "Time and Weather in ";
    title_string += city;
    title_string += ":";
    Text title_bar;
    title_bar.setFont(f1);
    title_bar.setString(title_string);
    title_bar.setCharacterSize(40);
    title_bar.setFillColor(Color::Black);
    title_bar.setFillColor(sf::Color(20,100,200));

    //Create the time text
    Text input_time;
    input_time.setFont(f1);
    input_time.setString("Enter 24h Time: ");
    input_time.setCharacterSize(24);
    input_time.setFillColor(Color::Black);
    input_time.setPosition(100.f, 200.f);

    //Create time textbox
    Textbox timeTextbox(24, Color::Black, false);
    timeTextbox.setFont(f1);
    timeTextbox.setPosition({280, 195});
    timeTextbox.setLimit(true, 4);

    //Create time edit button
    // Button timeEdit("Edit", {75, 25}, 20, Color::Black, Color::White);
    // timeEdit.setFont(f1);
    // timeEdit.setPosition({220,205});
    Button timeEdit("", {75, 25}, 20, Color::White, Color::White);
    timeEdit.setFont(f1);
    timeEdit.setPosition({265,200});

    //Create weather text
    Text input_weather;
    input_weather.setFont(f1);
    input_weather.setString("Weather: ");
    input_weather.setCharacterSize(24);
    input_weather.setFillColor(Color::Black);
    input_weather.setPosition(100.f, 300.f);

    //Create the actual value of the weather
    string Weather_Value = to_string((int)getWeather(city));
    Weather_Value += "C";
    Text Display_Weather_Value;
    Display_Weather_Value.setFont(f1);
    Display_Weather_Value.setString(Weather_Value);
    Display_Weather_Value.setCharacterSize(24);
    Display_Weather_Value.setFillColor(Color::Black);

    //Create the back button
    Button backButton("Back", {100, 50}, 24, Color::Black, Color::White);
    backButton.setFont(f1);
    backButton.setPosition({25, 525});

    //Create the Go button
    Button goButton("Go!", {100, 50}, 24, Color::Black, Color::White);
    goButton.setFont(f1);
    goButton.setPosition({675, 525});

    while(window.isOpen())
    {
        Event event;

        while(window.pollEvent(event))
        {
            switch (event.type)
            {
            case Event::Closed:
                window.close();
                break;
            case Event::MouseButtonReleased:
                if(timeEdit.isMouseOver(window))
                {
                    timeTextbox.setSelected(true);
                    timeEdit.setBackColor(Color::Green);
                }else
                {
                    timeTextbox.setSelected(false);
                    timeEdit.setBackColor(Color::White);
                }
            case Event::MouseMoved:
                if(backButton.isMouseOver(window))
                {
                    backButton.setTextColor(Color::Black);
                    backButton.setBackColor(Color::White);
                } else
                {
                    backButton.setTextColor(Color::White);
                    backButton.setBackColor(Color::Black);  
                }
                if(timeEdit.isMouseOver(window))
                {
                    // timeEdit.setTextColor(Color::Black);
                    // timeEdit.setBackColor(Color::White);
                    timeEdit.setOutline(2,Color::Blue);
                } else
                {
                    // timeEdit.setTextColor(Color::White);
                    // timeEdit.setBackColor(Color::Black);
                    timeEdit.setOutline(2,Color::Black);  
                }
                if(goButton.isMouseOver(window))
                {
                    goButton.setTextColor(Color::Black);
                    goButton.setBackColor(Color::White);
                } else
                {
                    goButton.setTextColor(Color::White);
                    goButton.setBackColor(Color::Black);  
                }
                break;
            case Event::MouseButtonPressed:
                if(backButton.isMouseOver(window))
                {
                    ToF = true;
                }
                if(!(time_st.empty()) && isIntegerString(time_st))
                {
                    if(0 <= stoi(time_st) && stoi(time_st) <= 2400)
                    {
                        if(goButton.isMouseOver(window))
                        {
                            Suggest_Activity(window, city, time_st);
                        }
                    }
                }
                break;
            case Event::TextEntered:
                if(timeTextbox.isSelectedText())
                {
                    // timeEdit.setBackColor(Color::Green);
                    timeTextbox.typedOn(event);
                    time_st = timeTextbox.getText();
                }
                break;
            }
        }

        //Clear the window
        window.clear(Color(200,200,200));

        //Draw the objects
        window.draw(title_bar);
        window.draw(input_time);
        window.draw(input_weather);
        backButton.drawTo(window);
        timeEdit.drawTo(window);
        timeTextbox.drawTo(window);
        window.draw(Display_Weather_Value);
        goButton.drawTo(window);

        //Set the positions of the objects
        title_bar.setPosition({0,0});
        Display_Weather_Value.setPosition(200.f, 300.f);

        //Display the window
        window.display();

        if(ToF)
        {
            break;
        }
    }

}

int main() 
{
    // Create the Window
    RenderWindow homepage(VideoMode(Width, Height), "Active City by Soud Al Kharji, Yousif Alhajji, Eirini Theodorakopoulou, Viraj Jaswani");
    homepage.setKeyRepeatEnabled(true);

    // Load in the font
    Font f1;
    if (!f1.loadFromFile("coolvetica rg.otf")) //Check the README
    {
        cout << "Error loading font" << endl;
        return -1;
    }

    // Create the title bar
    Text title_bar;
    title_bar.setFont(f1);
    title_bar.setString("Active City");
    title_bar.setCharacterSize(65);
    title_bar.setFillColor(sf::Color(20,100,200));
    title_bar.setPosition(240.f, 0);

    // Mykonos Button
    Button_Sprite btn1("Mykonos", {325, 150}, 50, "Mykonos.png", Color::White); //Check the README
    btn1.setFont(f1);
    btn1.setPosition({50, 120});

    // Bali Button
    Button_Sprite btn2("Bali", {325, 150}, 50, "Bali.png", Color::White); //Check the README
    btn2.setFont(f1);
    btn2.setPosition({425, 120});

    //Athens Button
    Button_Sprite btn3("Athens", {325, 150}, 50, "Athens.png", Color::White); //Check the README
    btn3.setFont(f1);
    btn3.setPosition({50, 320});

    //Jakarta Button
    Button_Sprite btn4("Jakarta", {325, 150}, 50, "Jakarta.png", Color::White); //Check the README
    btn4.setFont(f1);
    btn4.setPosition({425, 320});

    //While loop to check if the homepage is open
    while (homepage.isOpen()) 
    {
        Event event;

        while (homepage.pollEvent(event)) 
        {
            switch (event.type) 
            {
                case Event::Closed:
                    homepage.close();
                    break;

                case Event::MouseMoved:
                    if (btn1.isMouseOver(homepage)) 
                    {
                        btn1.setTextColor(Color::Black);
                    } else 
                    {
                        btn1.setTextColor(Color::White);
                    }

                    if (btn2.isMouseOver(homepage)) 
                    {
                        btn2.setTextColor(Color::Black);
                    } else 
                    {
                        btn2.setTextColor(Color::White);
                    }

                    if (btn3.isMouseOver(homepage)) 
                    {
                        btn3.setTextColor(Color::Black);
                    } else 
                    {
                        btn3.setTextColor(Color::White);
                    }

                    if (btn4.isMouseOver(homepage)) 
                    {
                        btn4.setTextColor(Color::Black);
                    } else 
                    {
                        btn4.setTextColor(Color::White);
                    }
                    break;

                case Event::MouseButtonPressed:
                    if(btn1.isMouseOver(homepage))
                    {
                        Time_Weather(homepage, "Mykonos");
                    }
                    else if(btn2.isMouseOver(homepage))
                    {
                        Time_Weather(homepage, "Bali");
                    }
                    else if(btn3.isMouseOver(homepage))
                    {
                        Time_Weather(homepage, "Athens");
                        
                    }
                    else if(btn4.isMouseOver(homepage))
                    {
                        Time_Weather(homepage, "Jakarta");
                    }
                    break;
            }
        }

        //Clear the homepage 
        homepage.clear(Color(200,200,200));

        // Draw Objects
        homepage.draw(title_bar);
        btn1.drawTo(homepage);
        btn2.drawTo(homepage);
        btn3.drawTo(homepage);
        btn4.drawTo(homepage);

        //Display the homepage
        homepage.display();
    }

    return 0;
}