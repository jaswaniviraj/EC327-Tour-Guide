#pragma once

#include <SFML/Graphics.hpp>
#include <iostream>
#include <sstream>

using namespace std;
using namespace sf;

//Class used to define a button with no sprite
class Button
{
public:
    Button() { }

    Button(string t, Vector2f size, int charSize, Color bgColor, Color textColor)
    {
        text.setString(t);
        text.setFillColor(textColor);
        text.setCharacterSize(charSize);
        button.setFillColor(bgColor);
        button.setSize(size);
    }

    void setFont(Font &font)
    {
        text.setFont(font);
    }

    void setBackColor(Color color)
    {
        button.setFillColor(color);
    }

    void setTextColor(Color color)
    {
        text.setFillColor(color);
    }

    void setPosition(Vector2f pos)
    {
        button.setPosition(pos);

        float xPos = (pos.x + button.getSize().x / 2) - (text.getGlobalBounds().width / 2);
        float yPos = (pos.y + button.getSize().y / 2) - (text.getGlobalBounds().height / 2) - 7;
        text.setPosition({xPos, yPos});
    }

    void drawTo(RenderWindow &window)
    {
        window.draw(button);
        window.draw(text);
    }

    bool isMouseOver(RenderWindow &window)
    {
        float mouseX = Mouse::getPosition(window).x;
        float mouseY = Mouse::getPosition(window).y;

        float btnPosX = button.getPosition().x;
        float btnPosY = button.getPosition().y;

        float btnxPosWidth = button.getPosition().x + button.getGlobalBounds().width;
        float btnyPosHeight = button.getPosition().y + button.getGlobalBounds().height;

        if (mouseX < btnxPosWidth && mouseX > btnPosX && mouseY < btnyPosHeight && mouseY > btnPosY)
        {
            return true;
        }
        return false;
    }

    void setOutline(float thickness,Color Color)
    {
        button.setOutlineThickness(thickness);
        button.setOutlineColor(Color);
    }

private:
    RectangleShape button;
    Text text;
};


//Class used to define a button with a sprite
class Button_Sprite 
{
public:
    Button_Sprite() {}

    Button_Sprite(string t, Vector2f size, int charSize, string imagePath, Color textColor) 
    {
        if (!texture.loadFromFile(imagePath)) //Check the README
        {
            cout << "Error loading texture" << endl; 
        }
        sprite.setTexture(texture);
        sprite.setScale(size.x / texture.getSize().x, size.y / texture.getSize().y);

        text.setString(t);
        text.setFillColor(textColor);
        text.setCharacterSize(charSize);
    }

    void setFont(Font &font) 
    {
        text.setFont(font);
    }

    void setTextColor(Color color) 
    {
        text.setFillColor(color);
    }

    void setPosition(Vector2f pos) 
    {
        sprite.setPosition(pos);

        float xPos = (pos.x + sprite.getGlobalBounds().width / 2) - (text.getGlobalBounds().width / 2);
        float yPos = (pos.y + sprite.getGlobalBounds().height / 2) - (text.getGlobalBounds().height / 2);
        text.setPosition({xPos, yPos});
    }

    void drawTo(RenderWindow &window) 
    {
        window.draw(sprite);
        window.draw(text);
    }

    bool isMouseOver(RenderWindow &window) 
    {
        float mouseX = Mouse::getPosition(window).x;
        float mouseY = Mouse::getPosition(window).y;

        float btnPosX = sprite.getPosition().x;
        float btnPosY = sprite.getPosition().y;

        float btnxPosWidth = sprite.getPosition().x + sprite.getGlobalBounds().width;
        float btnyPosHeight = sprite.getPosition().y + sprite.getGlobalBounds().height;

        if (mouseX < btnxPosWidth && mouseX > btnPosX && mouseY < btnyPosHeight && mouseY > btnPosY) 
        {
            return true;
        }
        return false;
    }

private:
    Texture texture;
    Sprite sprite;
    Text text;
};